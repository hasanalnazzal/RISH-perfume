"use client";

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { FiHeart, FiEye } from 'react-icons/fi';
import { FaStar } from 'react-icons/fa';
import { AspectRatio } from '@/components/ui/aspect-ratio';

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  imageSrc: string;
  rating?: number;
  description?: string;
  outOfStock?: boolean;
  discount?: number;
}

export default function ProductCard({
  id,
  name,
  price,
  originalPrice,
  imageSrc,
  rating = 5,
  description,
  outOfStock = false,
  discount,
}: ProductCardProps) {
  return (
    <div className="group relative product-card">
      <div className="relative">
        <AspectRatio ratio={1 / 1}>
          <Image
            src={imageSrc}
            alt={name}
            fill
            className="object-cover rounded-t-md transition-transform duration-300 group-hover:scale-105"
          />
        </AspectRatio>

        {discount && (
          <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 text-xs font-medium rounded">
            Discount {discount}%
          </div>
        )}

        {outOfStock && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-t-md">
            <span className="text-white font-semibold">Out of Stock</span>
          </div>
        )}

        <div className="absolute right-2 bottom-2 flex flex-col gap-2">
          <button
            className="bg-white p-2 rounded-full shadow-sm hover:bg-gray-100 transition-colors"
            aria-label="Add to wishlist"
          >
            <FiHeart className="h-5 w-5 text-gray-700" />
          </button>

          <button
            className="bg-white p-2 rounded-full shadow-sm hover:bg-gray-100 transition-colors"
            aria-label="Quick view"
          >
            <FiEye className="h-5 w-5 text-gray-700" />
          </button>
        </div>
      </div>

      <div className="p-4">
        <Link href={`/product/${id}`}>
          <h3 className="text-lg font-medium mb-1 hover:text-[#a46159] transition-colors">
            {name}
          </h3>
        </Link>

        {description && (
          <p className="text-sm text-gray-600 mb-2">{description}</p>
        )}

        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center space-x-1">
            {[...Array(5)].map((_, i) => (
              <FaStar
                key={i}
                className={`${
                  i < rating ? 'text-amber-400' : 'text-gray-300'
                } h-4 w-4`}
              />
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            {originalPrice && (
              <span className="text-gray-400 line-through text-sm mr-2">
                {originalPrice} SAR
              </span>
            )}
            <span className="font-semibold text-lg">{price} SAR</span>
          </div>

          <button
            disabled={outOfStock}
            className={`rounded-md px-3 py-1.5 text-sm flex items-center gap-1 ${
              outOfStock
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-[#1c221c] text-white hover:opacity-90 transition-opacity'
            }`}
          >
            Add to cart
          </button>
        </div>
      </div>
    </div>
  );
}
