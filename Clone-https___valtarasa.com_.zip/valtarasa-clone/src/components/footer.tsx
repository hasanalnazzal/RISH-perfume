"use client";

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { FiInstagram, FiTwitter, FiMessageCircle, FiPhone } from 'react-icons/fi';
import { FaTiktok, FaSnapchatGhost, FaWhatsapp } from 'react-icons/fa';
import { MdEmail } from 'react-icons/md';

export default function Footer() {
  return (
    <footer className="bg-[#1c221c] text-white">
      <div className="valtara-container py-12">
        <div className="flex flex-col md:flex-row justify-between">
          <div className="mb-8 md:mb-0">
            <h3 className="text-lg font-semibold mb-4">Important Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/blog" className="hover:text-[#e69d95] transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/valtara-story" className="hover:text-[#e69d95] transition-colors">
                  VALTARA STORY
                </Link>
              </li>
              <li>
                <Link href="/return-policy" className="hover:text-[#e69d95] transition-colors">
                  Return Policy
                </Link>
              </li>
              <li>
                <Link href="/privacy-policy" className="hover:text-[#e69d95] transition-colors">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>

          <div className="mb-8 md:mb-0 max-w-md">
            <div className="flex justify-center md:justify-start mb-4">
              <div className="relative h-10 w-40">
                <Image
                  src="/logo.png"
                  alt="Valtara"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
            <p className="text-sm text-gray-300 text-center md:text-left">
              فالتارا، متجر عطور فاخر تابع لشركة رفد الطيب (س.ت: 2050196383)، موثق من المركز السعودي للأعمال، يقدم عطورًا مميزة بجودة عالية وتصاميم فريدة لتجربة لا تُنسى.
            </p>

            <div className="mt-4">
              <div className="flex items-center justify-center md:justify-start mb-2">
                <div className="mr-2 bg-[#29A71A] p-1 rounded">
                  <Image
                    src="https://ext.same-assets.com/3949388833/1601467542.png"
                    alt="VAT"
                    width={18}
                    height={18}
                  />
                </div>
                <span className="text-sm">VAT Account Number</span>
              </div>
              <p className="text-lg font-bold text-center md:text-left">312559566100003</p>
            </div>
          </div>

          <div>
            <div className="flex flex-col items-center md:items-end space-y-4">
              <Link
                href="/whatsapp"
                className="flex items-center gap-2 bg-[#1c221c] border border-white px-4 py-2 rounded-md hover:bg-white/10 transition-colors"
              >
                <FaWhatsapp className="h-5 w-5" />
                <span>Whatsapp</span>
              </Link>

              <Link
                href="mailto:info@valtarasa.com"
                className="flex items-center gap-2 bg-[#1c221c] border border-white px-4 py-2 rounded-md hover:bg-white/10 transition-colors"
              >
                <MdEmail className="h-5 w-5" />
                <span>Email</span>
              </Link>

              <div className="flex items-center gap-4 mt-4">
                <Link href="https://www.instagram.com/valtara.sa" target="_blank" className="text-white hover:text-[#e69d95]">
                  <FiInstagram className="h-6 w-6" />
                </Link>
                <Link href="https://x.com/valtara_sa" target="_blank" className="text-white hover:text-[#e69d95]">
                  <FiTwitter className="h-6 w-6" />
                </Link>
                <Link href="https://www.snapchat.com/add/valtarasa" target="_blank" className="text-white hover:text-[#e69d95]">
                  <FaSnapchatGhost className="h-6 w-6" />
                </Link>
                <Link href="https://www.tiktok.com/@valtarasa" target="_blank" className="text-white hover:text-[#e69d95]">
                  <FaTiktok className="h-6 w-6" />
                </Link>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-300 mb-4 md:mb-0">
              Copyright | 2025 <Link href="/" className="hover:text-[#e69d95]">Valtara</Link>
            </p>

            <div className="flex flex-wrap justify-center gap-2">
              <Image src="https://ext.same-assets.com/3949388833/4121255940.png" alt="mada" width={36} height={24} />
              <Image src="https://ext.same-assets.com/3949388833/460673933.png" alt="credit_card" width={36} height={24} />
              <Image src="https://ext.same-assets.com/3949388833/2906261601.png" alt="bank" width={36} height={24} />
              <Image src="https://ext.same-assets.com/3949388833/738625231.png" alt="stc_pay" width={36} height={24} />
              <Image src="https://ext.same-assets.com/3949388833/516535226.png" alt="apple_pay" width={36} height={24} />
              <Image src="https://ext.same-assets.com/3949388833/635598631.png" alt="google_pay" width={36} height={24} />
              <Image src="https://ext.same-assets.com/3949388833/1088126603.png" alt="tamara_installment" width={36} height={24} />
              <Image src="https://ext.same-assets.com/3949388833/3508165644.png" alt="madfu_installment" width={36} height={24} />
              <Image src="https://ext.same-assets.com/3949388833/1431337994.png" alt="cod" width={36} height={24} />
              <Link href="https://eauthenticate.saudibusiness.gov.sa/certificate-details/0000134139" target="_blank">
                <Image src="https://ext.same-assets.com/3949388833/4264896417.png" alt="value_added_tax" width={36} height={24} />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Whatsapp Float Button */}
      <Link
        href="https://wa.me/+966537023773?text=Hello...%20I%20have%20an%20inquiry%20about"
        className="fixed bottom-6 right-6 bg-[#29A71A] text-white p-3 rounded-full shadow-lg z-50 hover:bg-[#25961B] transition-colors"
        target="_blank"
      >
        <FaWhatsapp className="h-6 w-6" />
      </Link>
    </footer>
  );
}
