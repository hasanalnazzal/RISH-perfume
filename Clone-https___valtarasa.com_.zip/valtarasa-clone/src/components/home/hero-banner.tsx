"use client";

import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Carousel, CarouselItem } from '@/components/ui/carousel';

export default function HeroBanner() {
  const banners = [
    {
      id: 1,
      imageSrc: "https://ext.same-assets.com/2697704113/2458939685.jpeg",
      alt: "Valtara Perfume Collection",
      link: "/categories/1221698870",
    },
    {
      id: 2,
      imageSrc: "https://ext.same-assets.com/2697704113/194679555.jpeg",
      alt: "Valtara New Arrivals",
      link: "/categories/1221698870",
    },
    {
      id: 3,
      imageSrc: "https://ext.same-assets.com/2697704113/3508287944.jpeg",
      alt: "Valtara Special Offers",
      link: "/categories/1221698870",
    },
  ];

  return (
    <section className="relative w-full overflow-hidden">
      <Carousel
        options={{
          loop: true,
          align: "start",
        }}
        className="w-full"
      >
        {banners.map((banner) => (
          <CarouselItem key={banner.id} className="w-full">
            <Link href={banner.link}>
              <div className="relative w-full h-[70vh] md:h-[85vh]">
                <Image
                  src={banner.imageSrc}
                  alt={banner.alt}
                  fill
                  className="object-cover"
                  priority={banner.id === 1}
                />
              </div>
            </Link>
          </CarouselItem>
        ))}
      </Carousel>
    </section>
  );
}
