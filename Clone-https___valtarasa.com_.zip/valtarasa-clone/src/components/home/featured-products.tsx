"use client";

import React from 'react';
import ProductCard from '@/components/products/product-card';

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  imageSrc: string;
  description?: string;
  outOfStock?: boolean;
  discount?: number;
}

interface FeaturedProductsProps {
  title: string;
  products: Product[];
}

export default function FeaturedProducts({ title, products }: FeaturedProductsProps) {
  return (
    <section className="py-12 bg-gray-50">
      <div className="valtara-container">
        <h2 className="section-title">{title}</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              price={product.price}
              originalPrice={product.originalPrice}
              imageSrc={product.imageSrc}
              description={product.description}
              outOfStock={product.outOfStock}
              discount={product.discount}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
