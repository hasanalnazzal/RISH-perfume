"use client";

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { FiSearch, FiShoppingCart, FiUser, FiMenu } from 'react-icons/fi';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';

export default function MainNav() {
  return (
    <div className="bg-[#1c221c] text-white">
      {/* Top bar */}
      <div className="border-b border-white/10">
        <div className="valtara-container flex justify-between items-center py-3">
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1 text-sm">
              <span>English</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            </button>
          </div>
          <div>
            <a href="mailto:info@valtarasa.com" className="text-sm">
              info@valtarasa.com
            </a>
          </div>
        </div>
      </div>

      {/* Main navigation */}
      <div className="valtara-container py-4">
        <div className="flex justify-between items-center">
          {/* Mobile menu trigger */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white">
                  <FiMenu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] bg-[#1c221c] text-white">
                <div className="flex flex-col gap-4 py-6">
                  <Link
                    href="/"
                    className="text-lg font-medium hover:text-[#e69d95] transition-colors"
                  >
                    Home
                  </Link>
                  <Link
                    href="/offers"
                    className="text-lg font-medium hover:text-[#e69d95] transition-colors"
                  >
                    Offers
                  </Link>
                  <Link
                    href="/for-him"
                    className="text-lg font-medium hover:text-[#e69d95] transition-colors"
                  >
                    FOR HUM
                  </Link>
                  <Link
                    href="/for-her"
                    className="text-lg font-medium hover:text-[#e69d95] transition-colors"
                  >
                    FOR HER
                  </Link>
                  <Link
                    href="/unisex"
                    className="text-lg font-medium hover:text-[#e69d95] transition-colors"
                  >
                    UNISEX
                  </Link>
                  <Link
                    href="/packages"
                    className="text-lg font-medium hover:text-[#e69d95] transition-colors"
                  >
                    بكجات
                  </Link>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Logo */}
          <div className="flex-1 flex justify-center md:justify-start">
            <Link href="/" className="block">
              <div className="relative h-8 w-32">
                <Image
                  src="/logo.png"
                  alt="Valtara"
                  fill
                  className="object-contain"
                  priority
                />
              </div>
            </Link>
          </div>

          {/* Desktop navigation links */}
          <div className="hidden md:flex items-center justify-center flex-1">
            <nav className="flex items-center gap-6">
              <Link
                href="/offers"
                className="text-sm font-medium hover:text-[#e69d95] transition-colors"
              >
                Offers
              </Link>
              <Link
                href="/for-him"
                className="text-sm font-medium hover:text-[#e69d95] transition-colors"
              >
                FOR HUM
              </Link>
              <Link
                href="/for-her"
                className="text-sm font-medium hover:text-[#e69d95] transition-colors"
              >
                FOR HER
              </Link>
              <Link
                href="/unisex"
                className="text-sm font-medium hover:text-[#e69d95] transition-colors"
              >
                UNISEX
              </Link>
              <Link
                href="/packages"
                className="text-sm font-medium hover:text-[#e69d95] transition-colors"
              >
                بكجات
              </Link>
            </nav>
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-3">
            <button className="text-white focus:outline-none">
              <FiSearch className="h-5 w-5" />
            </button>
            <Link href="/account" className="text-white">
              <FiUser className="h-5 w-5" />
            </Link>
            <Link href="/cart" className="text-white relative">
              <FiShoppingCart className="h-5 w-5" />
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                0
              </span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
