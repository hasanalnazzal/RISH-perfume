import React from 'react';
import HeroBanner from '@/components/home/hero-banner';
import FeaturedProducts from '@/components/home/featured-products';
import Image from 'next/image';
import Link from 'next/link';

export default function Home() {
  // Sample product data for packages
  const packages = [
    {
      id: '1',
      name: 'بكج يليق فيك (فيانتو - امبرو)',
      price: 230,
      originalPrice: 460,
      imageSrc: 'https://ext.same-assets.com/2697704113/1466627356.jpeg',
      outOfStock: true,
      discount: 50,
    },
    {
      id: '2',
      name: 'بكج له ولها (لافينا - امبرو)',
      price: 230,
      originalPrice: 460,
      imageSrc: 'https://ext.same-assets.com/2697704113/3779188291.jpeg',
      outOfStock: true,
      discount: 50,
    },
    {
      id: '3',
      name: 'بكج يليق بها (فولر - لافينا)',
      price: 230,
      originalPrice: 460,
      imageSrc: 'https://ext.same-assets.com/2697704113/248010465.jpeg',
      outOfStock: true,
      discount: 50,
    },
  ];

  // Sample product data for featured products
  const featuredProducts = [
    {
      id: '4',
      name: 'AMBRO-امبرو',
      price: 230,
      imageSrc: 'https://ext.same-assets.com/2697704113/636915591.jpeg',
      description: 'حضور طاغي',
      outOfStock: true,
    },
    {
      id: '5',
      name: 'LAVINA-لافينا',
      price: 230,
      imageSrc: 'https://ext.same-assets.com/2697704113/3405057328.jpeg',
      description: 'ببساطة هي الأجمل',
      outOfStock: true,
    },
  ];

  // Sample product data for new arrivals
  const newArrivals = [
    {
      id: '6',
      name: 'VOLAR-فولار',
      price: 230,
      imageSrc: 'https://ext.same-assets.com/2697704113/1104168664.jpeg',
      outOfStock: true,
    },
    {
      id: '7',
      name: 'VIANTO-فيانتو',
      price: 230,
      imageSrc: 'https://ext.same-assets.com/2697704113/3000089219.jpeg',
      description: 'عطري لكل الأوقات',
      outOfStock: true,
    },
  ];

  return (
    <div>
      <HeroBanner />

      {/* Packages Section */}
      <FeaturedProducts title="بكجات العيد" products={packages} />

      {/* Featured Products Section */}
      <FeaturedProducts title="منتجات مميزة" products={featuredProducts} />

      {/* Banner Section */}
      <section className="py-12">
        <div className="valtara-container">
          <Link href="/latest-products">
            <div className="relative w-full h-40 md:h-64 rounded-lg overflow-hidden">
              <Image
                src="https://ext.same-assets.com/2697704113/2372077074.jpeg"
                alt="Latest Products"
                fill
                className="object-cover hover:scale-105 transition-transform duration-500"
              />
            </div>
          </Link>
        </div>
      </section>

      {/* New Arrivals Section */}
      <FeaturedProducts title="يومي ومميز" products={newArrivals} />

      {/* Customer Reviews Section */}
      <section className="py-12 bg-gray-50">
        <div className="valtara-container">
          <h2 className="section-title">Customers Reviews</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Customer Review 1 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="mr-4">
                  <Image
                    src="https://ext.same-assets.com/2697704113/2781949437.jpeg"
                    alt="AHMED ALJAMIE"
                    width={50}
                    height={50}
                    className="rounded-full"
                  />
                </div>
                <div>
                  <h4 className="font-semibold">AHMED ALJAMIE</h4>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-amber-400">★</span>
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">رائحة مميزة</p>
            </div>

            {/* Customer Review 2 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="mr-4">
                  <Image
                    src="https://ext.same-assets.com/2697704113/1492292449.jpeg"
                    alt="Abdullah Alkharashi"
                    width={50}
                    height={50}
                    className="rounded-full"
                  />
                </div>
                <div>
                  <h4 className="font-semibold">Abdullah Alkharashi</h4>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-amber-400">★</span>
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">Stronger With You</p>
            </div>

            {/* Customer Review 3 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="mr-4">
                  <div className="bg-gray-200 w-12 h-12 flex items-center justify-center rounded-full">
                    <span className="text-gray-600 text-xl">A</span>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold">Anonymous</h4>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-amber-400">★</span>
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">منتج رائع بجودة عالية</p>
            </div>
          </div>
        </div>
      </section>

      {/* Shipping Info Section */}
      <section className="py-8 bg-white">
        <div className="valtara-container">
          <div className="flex flex-col md:flex-row items-center justify-center gap-8">
            <div className="text-center max-w-xs">
              <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                </svg>
              </div>
              <h3 className="font-semibold mb-2">الشحن داخل الرياض:</h3>
              <p className="text-sm text-gray-600">24-48 ساعة</p>
            </div>

            <div className="text-center max-w-xs">
              <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <h3 className="font-semibold mb-2">الشحن للمدن الرئيسية:</h3>
              <p className="text-sm text-gray-600">2-5 أيام</p>
            </div>

            <div className="text-center max-w-xs">
              <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
                </svg>
              </div>
              <h3 className="font-semibold mb-2">الشحن الدولي:</h3>
              <p className="text-sm text-gray-600">5-10 أيام</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
