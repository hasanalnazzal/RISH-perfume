"use client";

import React from 'react';
import Link from 'next/link';
import ProductCard from '@/components/products/product-card';

export default function PackagesPage() {
  // Sample product data for packages
  const products = [
    {
      id: '1',
      name: 'بكج يليق فيك (فيانتو - امبرو)',
      price: 230,
      originalPrice: 460,
      imageSrc: 'https://ext.same-assets.com/2697704113/1466627356.jpeg',
      outOfStock: true,
      discount: 50,
    },
    {
      id: '2',
      name: 'بكج له ولها (لافينا - امبرو)',
      price: 230,
      originalPrice: 460,
      imageSrc: 'https://ext.same-assets.com/2697704113/3779188291.jpeg',
      outOfStock: true,
      discount: 50,
    },
    {
      id: '3',
      name: 'بكج يليق بها (فولر - لافينا)',
      price: 230,
      originalPrice: 460,
      imageSrc: 'https://ext.same-assets.com/2697704113/248010465.jpeg',
      outOfStock: true,
      discount: 50,
    },
  ];

  return (
    <div className="py-12">
      <div className="valtara-container">
        {/* Breadcrumbs */}
        <div className="mb-8 text-sm">
          <Link href="/" className="hover:text-[#a46159]">Home</Link>
          <span className="mx-2">/</span>
          <span className="text-gray-500">بكجات</span>
        </div>

        {/* Category Header */}
        <div className="mb-12 text-center">
          <h1 className="text-3xl font-bold mb-4">بكجات</h1>
          <p className="max-w-2xl mx-auto text-gray-600">
            اكتشف مجموعتنا الحصرية من بكجات العطور الفاخرة المجمعة لتكون هدية مثالية لأي مناسبة.
            استمتع بخصومات خاصة عند شراء العطور كمجموعة.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              price={product.price}
              originalPrice={product.originalPrice}
              imageSrc={product.imageSrc}
              outOfStock={product.outOfStock}
              discount={product.discount}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
