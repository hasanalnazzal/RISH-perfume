"use client";

import React from 'react';
import Link from 'next/link';
import ProductCard from '@/components/products/product-card';

export default function ForHerPage() {
  // Sample product data for women's perfumes
  const products = [
    {
      id: '5',
      name: 'LAVINA-لافينا',
      price: 230,
      imageSrc: 'https://ext.same-assets.com/2697704113/3405057328.jpeg',
      description: 'ببساطة هي الأجمل',
      outOfStock: true,
    },
  ];

  return (
    <div className="py-12">
      <div className="valtara-container">
        {/* Breadcrumbs */}
        <div className="mb-8 text-sm">
          <Link href="/" className="hover:text-[#a46159]">Home</Link>
          <span className="mx-2">/</span>
          <span className="text-gray-500">FOR HER</span>
        </div>

        {/* Category Header */}
        <div className="mb-12 text-center">
          <h1 className="text-3xl font-bold mb-4">FOR HER</h1>
          <p className="max-w-2xl mx-auto text-gray-600">
            Explore our exquisite collection of women's perfumes,
            designed to capture the essence of femininity with elegant and captivating fragrances.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              price={product.price}
              imageSrc={product.imageSrc}
              description={product.description}
              outOfStock={product.outOfStock}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
