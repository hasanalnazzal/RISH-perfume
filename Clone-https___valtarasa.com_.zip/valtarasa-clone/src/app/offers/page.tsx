"use client";

import React from 'react';
import Link from 'next/link';
import ProductCard from '@/components/products/product-card';
import Image from 'next/image';

export default function OffersPage() {
  // Sample product data for offers (combining packages with discount)
  const products = [
    {
      id: '1',
      name: 'بكج يليق فيك (فيانتو - امبرو)',
      price: 230,
      originalPrice: 460,
      imageSrc: 'https://ext.same-assets.com/2697704113/1466627356.jpeg',
      outOfStock: true,
      discount: 50,
    },
    {
      id: '2',
      name: 'بكج له ولها (لافينا - امبرو)',
      price: 230,
      originalPrice: 460,
      imageSrc: 'https://ext.same-assets.com/2697704113/3779188291.jpeg',
      outOfStock: true,
      discount: 50,
    },
    {
      id: '3',
      name: 'بكج يليق بها (فولر - لافينا)',
      price: 230,
      originalPrice: 460,
      imageSrc: 'https://ext.same-assets.com/2697704113/248010465.jpeg',
      outOfStock: true,
      discount: 50,
    },
  ];

  return (
    <div className="py-12">
      <div className="valtara-container">
        {/* Breadcrumbs */}
        <div className="mb-8 text-sm">
          <Link href="/" className="hover:text-[#a46159]">Home</Link>
          <span className="mx-2">/</span>
          <span className="text-gray-500">Offers</span>
        </div>

        {/* Hero Banner */}
        <div className="mb-12 relative rounded-lg overflow-hidden">
          <div className="relative w-full h-[300px]">
            <Image
              src="https://ext.same-assets.com/2697704113/2458939685.jpeg"
              alt="Special Offers"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white p-6">
              <h1 className="text-4xl font-bold mb-4">Special Offers</h1>
              <p className="text-xl max-w-2xl text-center">
                Discover our exclusive deals and save up to 50% off on our premium perfume collections.
              </p>
            </div>
          </div>
        </div>

        {/* Offers Description */}
        <div className="mb-8 text-center">
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            For a limited time, enjoy special discounts on our carefully curated perfume packages.
            Perfect for gifting or treating yourself to a new fragrance experience.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              price={product.price}
              originalPrice={product.originalPrice}
              imageSrc={product.imageSrc}
              outOfStock={product.outOfStock}
              discount={product.discount}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
