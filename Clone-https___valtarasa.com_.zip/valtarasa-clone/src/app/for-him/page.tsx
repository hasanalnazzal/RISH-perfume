"use client";

import React from 'react';
import Link from 'next/link';
import ProductCard from '@/components/products/product-card';

export default function ForHimPage() {
  // Sample product data for men's perfumes
  const products = [
    {
      id: '4',
      name: 'AMBRO-امبرو',
      price: 230,
      imageSrc: 'https://ext.same-assets.com/2697704113/636915591.jpeg',
      description: 'حضور طاغي',
      outOfStock: true,
    },
    {
      id: '7',
      name: 'VIANTO-فيانتو',
      price: 230,
      imageSrc: 'https://ext.same-assets.com/2697704113/3000089219.jpeg',
      description: 'عطري لكل الأوقات',
      outOfStock: true,
    },
  ];

  return (
    <div className="py-12">
      <div className="valtara-container">
        {/* Breadcrumbs */}
        <div className="mb-8 text-sm">
          <Link href="/" className="hover:text-[#a46159]">Home</Link>
          <span className="mx-2">/</span>
          <span className="text-gray-500">FOR HUM</span>
        </div>

        {/* Category Header */}
        <div className="mb-12 text-center">
          <h1 className="text-3xl font-bold mb-4">FOR HUM</h1>
          <p className="max-w-2xl mx-auto text-gray-600">
            Discover our exclusive collection of men's perfumes,
            crafted with the finest ingredients to provide long-lasting fragrances that make a statement.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              price={product.price}
              imageSrc={product.imageSrc}
              description={product.description}
              outOfStock={product.outOfStock}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
