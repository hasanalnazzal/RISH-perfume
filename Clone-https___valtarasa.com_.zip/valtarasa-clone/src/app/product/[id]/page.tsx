import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { FaStar, FaShoppingCart, FaHeart } from 'react-icons/fa';
import { AspectRatio } from '@/components/ui/aspect-ratio';

type ProductPageProps = {
  params: {
    id: string;
  };
};

// This would ideally come from an API or database
const getProductData = (id: string) => {
  const products = {
    '1': {
      id: '1',
      name: 'بكج يليق فيك (فيانتو - امبرو)',
      price: 230,
      originalPrice: 460,
      description: 'مجموعة عطور فاخرة تجمع بين عطر فيانتو للرجال وعطر امبرو، تركيبة مثالية لهدية مميزة.',
      images: [
        'https://ext.same-assets.com/2697704113/1466627356.jpeg',
        'https://ext.same-assets.com/2697704113/2908343960.jpeg',
      ],
      rating: 5,
      reviews: 12,
      outOfStock: true,
      discount: 50,
      category: 'packages',
    },
    '4': {
      id: '4',
      name: 'AMBRO-امبرو',
      price: 230,
      description: 'عطر مميز للرجال، يمنحك حضور طاغي. خشبي بمزيج من التوابل والفانيلا، يدوم طويلاً ويناسب المناسبات الرسمية.',
      images: [
        'https://ext.same-assets.com/2697704113/636915591.jpeg',
        'https://ext.same-assets.com/2697704113/2908343960.jpeg',
      ],
      rating: 5,
      reviews: 24,
      outOfStock: true,
      category: 'for-him',
    },
    '5': {
      id: '5',
      name: 'LAVINA-لافينا',
      price: 230,
      description: 'عطر نسائي فاخر، ببساطة هي الأجمل. تركيبة زهرية فاكهية مع لمسات من المسك والعنبر، تدوم طويلاً وتمنحك إحساساً بالأنوثة.',
      images: [
        'https://ext.same-assets.com/2697704113/3405057328.jpeg',
        'https://ext.same-assets.com/2697704113/3913003015.jpeg',
      ],
      rating: 5,
      reviews: 18,
      outOfStock: true,
      category: 'for-her',
    },
    '6': {
      id: '6',
      name: 'VOLAR-فولار',
      price: 230,
      description: 'عطر مميز للجنسين، يجمع بين الانتعاش والعمق. تركيبة فريدة تناسب جميع الأوقات والمناسبات.',
      images: [
        'https://ext.same-assets.com/2697704113/1104168664.jpeg',
        'https://ext.same-assets.com/2697704113/2138218172.jpeg',
      ],
      rating: 5,
      reviews: 9,
      outOfStock: true,
      category: 'unisex',
    },
    '7': {
      id: '7',
      name: 'VIANTO-فيانتو',
      price: 230,
      description: 'عطر رجالي فاخر، عطري لكل الأوقات. تركيبة منعشة مع لمسات خشبية، مثالي للاستخدام اليومي.',
      images: [
        'https://ext.same-assets.com/2697704113/3000089219.jpeg',
        'https://ext.same-assets.com/2697704113/132742350.jpeg',
      ],
      rating: 5,
      reviews: 15,
      outOfStock: true,
      category: 'for-him',
    },
  };

  return products[id as keyof typeof products] || null;
};

export default function ProductPage({ params }: ProductPageProps) {
  const product = getProductData(params.id);

  if (!product) {
    return (
      <div className="valtara-container py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
        <p className="mb-6">The product you are looking for does not exist.</p>
        <Link href="/" className="inline-block bg-[#1c221c] text-white px-4 py-2 rounded-md">
          Return to Home
        </Link>
      </div>
    );
  }

  return (
    <div className="py-12">
      <div className="valtara-container">
        {/* Breadcrumbs */}
        <div className="mb-8 text-sm">
          <Link href="/" className="hover:text-[#a46159]">Home</Link>
          <span className="mx-2">/</span>
          <Link href={`/${product.category}`} className="hover:text-[#a46159]">
            {product.category.charAt(0).toUpperCase() + product.category.slice(1).replace('-', ' ')}
          </Link>
          <span className="mx-2">/</span>
          <span className="text-gray-500">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Images */}
          <div>
            <div className="mb-4 border border-gray-200 rounded-lg overflow-hidden">
              <AspectRatio ratio={1/1}>
                <Image
                  src={product.images[0]}
                  alt={product.name}
                  fill
                  className="object-cover"
                />
              </AspectRatio>
            </div>

            {/* Image Gallery */}
            <div className="flex gap-2">
              {product.images.map((image, index) => (
                <div
                  key={index}
                  className="border border-gray-200 rounded-md overflow-hidden w-16 h-16 relative"
                >
                  <Image
                    src={image}
                    alt={`${product.name} - View ${index + 1}`}
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div>
            <h1 className="text-2xl font-bold mb-2">{product.name}</h1>

            {/* Rating */}
            <div className="flex items-center mb-4">
              <div className="flex mr-2">
                {[...Array(5)].map((_, i) => (
                  <FaStar
                    key={i}
                    className={`${
                      i < product.rating ? 'text-amber-400' : 'text-gray-300'
                    } h-4 w-4`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-500">
                ({product.reviews} reviews)
              </span>
            </div>

            {/* Price */}
            <div className="mb-6">
              {product.originalPrice && (
                <span className="text-gray-400 line-through text-lg mr-3">
                  {product.originalPrice} SAR
                </span>
              )}
              <span className="text-2xl font-bold">{product.price} SAR</span>

              {product.discount && (
                <span className="ml-3 bg-red-500 text-white px-2 py-1 text-xs font-medium rounded">
                  {product.discount}% OFF
                </span>
              )}
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Description</h3>
              <p className="text-gray-600">{product.description}</p>
            </div>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 mb-8">
              <button
                disabled={product.outOfStock}
                className={`px-6 py-3 rounded-md flex-1 flex items-center justify-center gap-2 ${
                  product.outOfStock
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-[#1c221c] text-white hover:opacity-90 transition-opacity'
                }`}
              >
                <FaShoppingCart />
                {product.outOfStock ? 'Out of Stock' : 'Add to Cart'}
              </button>

              <button className="px-6 py-3 rounded-md border border-[#1c221c] text-[#1c221c] hover:bg-[#1c221c] hover:text-white transition-colors flex items-center justify-center gap-2">
                <FaHeart />
                Add to Wishlist
              </button>
            </div>

            {/* Product Info */}
            <div className="border-t border-gray-200 pt-6">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500 mb-1">Category:</p>
                  <p className="font-medium">{product.category.replace('-', ' ')}</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Product ID:</p>
                  <p className="font-medium">{product.id}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Client-side interactivity note */}
        <div className="mt-16 p-4 bg-yellow-50 border border-yellow-200 rounded-md">
          <p className="text-yellow-800">
            Note: In a complete implementation, image gallery selection and "Add to Cart" functionality would be handled client-side.
            This demo shows a server-rendered version with limited interactivity.
          </p>
        </div>
      </div>
    </div>
  );
}
